import scrapy


class FilmesSpider(scrapy.Spider):
    name = 'filmes'
    start_urls = ['https://www.imdb.com/chart/top/']

    def parse(self, response):
        for filmes in response.css('.titleColumn'): ## Rodar para todos os filmes na lista(response.css)
         
            yield{
                'titulo' : filmes.css('.titleColumn a::text').get(),
                'ano' : filmes.css('.secondaryInfo ::text').get()[1:-1],
                'nota' : response.css('strong ::text').get()
            }
       
